"""Package with enum classes used while printing output data."""
