"""Package with classes for processing arguments from command line."""
