"""Package with interface implemented by all parameter classes."""
