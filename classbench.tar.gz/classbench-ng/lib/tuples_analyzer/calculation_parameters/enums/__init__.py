"""Package with enum classes used while computation parameters."""
