"""Package with classes for computation parameters."""
