"""Package with enum classes used while processing errors."""
