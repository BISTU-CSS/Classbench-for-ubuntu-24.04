"""Package with enum classes used while processing filter rules into generator of FilterRule instances."""
